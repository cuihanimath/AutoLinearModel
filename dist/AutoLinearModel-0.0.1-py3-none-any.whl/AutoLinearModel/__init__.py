import os
import sys

os.chdir(os.getcwd()+'/AutoLinearModel/')
